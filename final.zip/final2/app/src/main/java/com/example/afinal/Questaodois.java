package com.example.afinal;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.R;
import androidx.appcompat.app.AppCompatActivity;

public class Questaodois extends AppCompatActivity {
    private Button btnBBoito, btnRdois, btnCtres, btnTC;
    private TextView txtCashQ2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questao_dois);

        btnBBoito = findViewById(R.id.btnBBoito);
        btnRdois = findViewById(R.id.btnOnze);
        btnCtres = findViewById(R.id.btnCtres);
        btnTC = findViewById(R.id.btnCinco);

        txtCashQ2 = findViewById(R.id.txtCashQ10);

        txtCashQ2.setText(" " + MainActivity.acertos);

        btnBBoito.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirProx();
            }
        });
        btnRdois.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirProx();
            }
        });
        btnCtres.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int acertos = acertos + 10;
                abrirProx();
            }
        });
        btnTC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirProx();
            }
        });
    }
    private void abrirProx()
    {
        Intent janelab = new Intent(this, Questaotres.class);
        startActivity(janelab);
        finish();
    }
    @Override
    public void onBackPressed() {
        Toast.makeText(this, "Você não pode voltar!", Toast.LENGTH_LONG).show();
    }
}
}
