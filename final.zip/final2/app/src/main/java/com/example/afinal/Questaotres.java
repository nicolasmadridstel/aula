package com.example.afinal;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Questaotres extends AppCompatActivity {
    private static final android.R.attr R = ;
    private Button btnBacca, btnYoda, btnSolo, btnJabba;
    private TextView txtCashQ3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questao_tres);

        btnBacca = findViewById(R.id.btnSete);
        btnYoda = findViewById(R.id.btnOnze);
        btnSolo = findViewById(R.id.btnDez);
        btnJabba = findViewById(R.id.btnCinco);
        txtCashQ3 = findViewById(R.id.txtCashQ10);

        txtCashQ3.setText(" " + MainActivity.acertos);

        btnBacca.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirProx();
            }
        });
        btnYoda.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int acertos = acertos + 10
            }
        });
        btnSolo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirProx();
            }
        });
        btnJabba.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirProx();
            }
        });
    }
    private void abrirProx()
    {
        Intent janela = new Intent(this, Gameover.class);
        startActivity(janela);
        finish();
    }


}
