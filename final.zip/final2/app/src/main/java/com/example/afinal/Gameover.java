package com.example.afinal;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Gameover extends AppCompatActivity {
    private static final android.R.attr R = ;
    private Button btnIrRestaurante, btnIrMenu;
    private TextView resultadoFinal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final_quiz);

        btnIrRestaurante = findViewById(R.id.btnIrRestaurante);
        btnIrMenu = findViewById(R.id.btnIrMenu);
        resultadoFinal = findViewById(R.id.resultadoFinal);

        resultadoFinal.setText(" " + MainActivity.acertos);

        // btnIrRestaurante.setOnClickListener(new View.OnClickListener() {
        //    @Override
        //   public void onClick(View v) {
        //       abrirRestaurante();
        //      }
        //  });
        btnIrMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirMenu();
            }
        });
    }
    // private void abrirRestaurante()
    //  {
    //    Intent janelar = new Intent(this, game.class);
    //    startActivity(janelar);
    //    finish();
    // }
    private void abrirMenu()
    {
        Intent janelam = new Intent(this, MainActivity.class);
        startActivity(janelam);
        finish();
    }
}
}
