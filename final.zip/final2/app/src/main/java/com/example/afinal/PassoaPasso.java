package com.example.afinal;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class PassoaPasso  extends AppCompatActivity {

    private static final android.R.attr R = ;
    private Button btnIniciarJogo2;
    private ImageButton btnVQ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_passo_a_passo);

        btnIniciarJogo2 = findViewById(R.id.btnIniciarJogo2);
        btnVQ = findViewById(R.id.btnVQ);

        btnIniciarJogo2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirPerum();
            }
        });
        btnVQ.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirMain();
            }
        });
    }
    private void abrirPerum()
    {
        Intent janelap = new Intent(this, Questaoum.class);
        startActivity(janelap);
    }
    private void abrirMain()
    {
        Intent janlelam = new Intent(this, MainActivity.class);
        startActivity(janlelam);
}

    private void setContentView() {
    }
}