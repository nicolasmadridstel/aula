package com.example.afinal;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Questaoum extends AppCompatActivity {
    private static final android.R.attr R = ;
    private Button btnPadme, btnRey, btnUnduli, btnLeia;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questao_um);

        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        btnPadme = findViewById(R.id.btnSete);
        btnRey = findViewById(R.id.btnOnze);
        btnUnduli = findViewById(R.id.btnDez);
        btnLeia = findViewById(R.id.btnCinco);

        btnPadme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirProx();
            }
        });
        btnRey.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirProx();
            }
        });
        btnUnduli.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirProx();
            }
        });
        btnLeia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int acertos = acertos + 10;
                abrirProx();
            }
        });
    }
    public void abrirProx()
    {
        Intent janelap = new Intent(this, Questaodois.class);
        startActivity(janelap);
        finish();
    }

    @Override
    public void onBackPressed() {
        Toast.makeText(this, "Você não pode voltar!", Toast.LENGTH_LONG).show();
    }
}

