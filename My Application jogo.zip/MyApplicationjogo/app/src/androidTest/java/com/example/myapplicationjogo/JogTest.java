package com.example.myapplicationjogo;

import junit.framework.TestCase;

public class JogTest extends TestCase {

}